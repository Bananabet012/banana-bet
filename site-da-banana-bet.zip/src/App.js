import React from "react";

function App() {
  return <div>Banana Bet - Em breve!</div>;
}

export default App;